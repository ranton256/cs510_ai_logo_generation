The below folders must be created:
images (This folder has the style images)
input (This folder has the font_contents inside it which has the three fonts)
logos (Generated Logos folder)
output (Style transfer folder)
shapenet (This cotains a folder named screenshots which has the shapenet dataset, and the metadata file (metadata.csv) )

Also, you must download imagenet-vgg-verydeep-19.mat and place it in the current folder

To run the UI, please run first_windows.py